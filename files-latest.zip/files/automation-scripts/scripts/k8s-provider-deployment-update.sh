#!/bin/bash

source ./configurations.txt

echo "logs are saving in $K8S_LOG_PATH file"
PRINT="echo ========================================================= | tee -a $K8S_LOG_PATH"
echo "###PROVIDER API K8S DEPLOYMENT###" | tee -a $K8S_LOG_PATH
eval "$PRINT"
date | tee -a $K8S_LOG_PATH
eval "$PRINT"

#==============key based authentication=================================#
echo "$DOCKER_REGISTRY_IP:443/$PROVIDER_DOCKER_IMAGE_NAME:v$PROVIDER_DOCKER_IMAGE_VERSION is updating..." | tee -a $K8S_LOG_PATH
eval "$PRINT"
ssh -o StrictHostKeyChecking=no $K8S_VM_USERNAME@$K8S_VM_IP kubectl set image $PROVIDER_DEPLOYMENT_NAME $PROVIDER_CONTAINER_NAME=$DOCKER_REGISTRY_IP:443/$PROVIDER_DOCKER_IMAGE_NAME:v$PROVIDER_DOCKER_IMAGE_VERSION -n $K8S_NAMESPACE --record=true | tee -a $K8S_LOG_PATH
eval "$PRINT"
ssh -o StrictHostKeyChecking=no $K8S_VM_USERNAME@$K8S_VM_IP kubectl get pods -n $K8S_NAMESPACE | tee -a $K8S_LOG_PATH
eval "$PRINT"
echo "AFTER 30 SECONDS RUN BELOW COMMAND TO GET STATUS OF POD " | tee -a $K8S_LOG_PATH
eval "$PRINT"
echo "ssh -o StrictHostKeyChecking=no $K8S_VM_USERNAME@$K8S_VM_IP kubectl get pods -n $K8S_NAMESPACE" | tee -a $K8S_LOG_PATH
eval "$PRINT"


#=============password based authentication ; if sshpass utility is available==============#
#read -p "Enter k8s Vm password  to login : " VPASSWORD
#sshpass -p $VPASSWORD ssh $K8S_VM_USERNAME@$K8S_VM_IP kubectl set image $PROVIDER_DEPLOYMENT_NAME $PROVIDER_CONTAINER_NAME=$DOCKER_REGISTRY_IP:443/$PROVIDER_DOCKER_IMAGE_NAME:v$PROVIDER_DOCKER_IMAGE_VERSION -n $K8S_NAMESPACE --record=true | tee -a $K8S_LOG_PATH
