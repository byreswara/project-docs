#!/bin/bash

source ./configurations.txt

echo "logs are saving in $DOCKER_LOG_PATH file"
PRINT="echo ========================================================= | tee -a $DOCKER_LOG_PATH"
echo "###PROVIDER API###" | tee -a $DOCKER_LOG_PATH
eval "$PRINT"
date | tee -a $DOCKER_LOG_PATH
eval "$PRINT"

#==============key based authentication=================================#

echo "copying $PROVIDER_TAR_FILEPATH to docker registry vm" | tee -a $DOCKER_LOG_PATH
eval "$PRINT"

if [ -f $PROVIDER_TAR_FILEPATH ]
  then
    scp -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $PROVIDER_TAR_FILEPATH $DOCKER_VM_USERNAME@$DOCKER_VM_IP: | tee -a $DOCKER_LOG_PATH
	echo $?
	eval "$PRINT" 
  else
    echo "$PROVIDER_TAR_FILEPATH file doesnot exist " | tee -a $DOCKER_LOG_PATH
    exit 1
	eval "$PRINT"
fi

echo "pushing $DOCKER_REGISTRY_IP:443/$PROVIDER_DOCKER_IMAGE_NAME:v$PROVIDER_DOCKER_IMAGE_VERSION image  to docker registery" | tee -a $DOCKER_LOG_PATH
eval "$PRINT"
#ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $DOCKER_VM_USERNAME@$DOCKER_VM_IP "docker load < $PROVIDER_TAR_FILENAME && docker tag $PROVIDER_DOCKER_IMAGE_NAME:v$PROVIDER_DOCKER_IMAGE_VERSION $DOCKER_REGISTRY_IP:443/$PROVIDER_DOCKER_IMAGE_NAME:v$PROVIDER_DOCKER_IMAGE_VERSION && docker login -u $DOCKER_REGISTRY_USERNAME -p $DOCKER_REGISTRY_PASSWORD $DOCKER_REGISTRY_IP:443 && docker push $DOCKER_REGISTRY_IP:443/$PROVIDER_DOCKER_IMAGE_NAME:v$PROVIDER_DOCKER_IMAGE_VERSION" | tee -a $DOCKER_LOG_PATH
echo ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $DOCKER_VM_USERNAME@$DOCKER_VM_IP "docker tag $PROVIDER_DOCKER_IMAGE_NAME:v$PROVIDER_DOCKER_IMAGE_VERSION $DOCKER_REGISTRY_IP:443/$PROVIDER_DOCKER_IMAGE_NAME:v$PROVIDER_DOCKER_IMAGE_VERSION && docker login -u $DOCKER_REGISTRY_USERNAME -p $DOCKER_REGISTRY_PASSWORD $DOCKER_REGISTRY_IP:443 && docker push $DOCKER_REGISTRY_IP:443/$PROVIDER_DOCKER_IMAGE_NAME:v$PROVIDER_DOCKER_IMAGE_VERSION" | tee -a $DOCKER_LOG_PATH
eval "$PRINT"
#=============password based authentication ; if sshpass utility is available==============#
#read -p "Enter Docker Vm password  to login : " VPASSWORD
#sshpass -p $VPASSWORD scp $PROVIDER_TAR_FILEPATH $DOCKER_VM_USERNAME@$DOCKER_VM_IP:  | tee -a $DOCKER_LOG_PATH
#sshpass -p $VPASSWORD ssh $DOCKER_VM_USERNAME@$DOCKER_VM_IP "docker load < $PROVIDER_TAR_FILENAME && docker tag $PROVIDER_DOCKER_IMAGE_NAME:v$PROVIDER_DOCKER_IMAGE_VERSION $DOCKER_REGISTRY_IP:443/$PROVIDER_DOCKER_IMAGE_NAME:v$PROVIDER_DOCKER_IMAGE_VERSION && docker login -u $DOCKER_REGISTRY_USERNAME -p $DOCKER_REGISTRY_PASSWORD $DOCKER_REGISTRY_IP:443 && docker push $DOCKER_REGISTRY_IP:443/$PROVIDER_DOCKER_IMAGE_NAME:v$PROVIDER_DOCKER_IMAGE_VERSION"  | tee -a $DOCKER_LOG_PATH
