#!/bin/bash

source ./configurations.txt

echo "logs are saving in $K8S_LOG_PATH file"
PRINT="echo ========================================================= | tee -a $K8S_LOG_PATH"
eval "$PRINT"
date | tee -a $K8S_LOG_PATH
eval "$PRINT"

#PROVIDER_DEPLOYMENT
echo "###PROVIDER API K8S DEPLOYMENT###" | tee -a $K8S_LOG_PATH
#==============key based authentication=================================#
eval "$PRINT"
echo "$DOCKER_REGISTRY_IP:443/$PROVIDER_DOCKER_IMAGE_NAME:v$PROVIDER_DOCKER_IMAGE_VERSION is updating..." | tee -a $K8S_LOG_PATH
eval "$PRINT"
ssh -o StrictHostKeyChecking=no $K8S_VM_USERNAME@$K8S_VM_IP kubectl set image $PROVIDER_DEPLOYMENT_NAME $PROVIDER_CONTAINER_NAME=$DOCKER_REGISTRY_IP:443/$PROVIDER_DOCKER_IMAGE_NAME:v$PROVIDER_DOCKER_IMAGE_VERSION -n $K8S_NAMESPACE --record=true | tee -a $K8S_LOG_PATH
eval "$PRINT"
#=============password based authentication ; if sshpass utility is available==============#
#read -p "Enter k8s Vm password  to login : " VPASSWORD
#sshpass -p $VPASSWORD ssh $K8S_VM_USERNAME@$K8S_VM_IP kubectl set image $PROVIDER_DEPLOYMENT_NAME $PROVIDER_CONTAINER_NAME=$DOCKER_REGISTRY_IP:443/$PROVIDER_DOCKER_IMAGE_NAME:v$PROVIDER_DOCKER_IMAGE_VERSION -n $K8S_NAMESPACE --record=true | tee -a $K8S_LOG_PATH

#PATIENT_DEPLOYMENT
echo "###PATIENT API K8S DEPLOYMENT###" | tee -a $K8S_LOG_PATH
#==============key based authentication=================================#
eval "$PRINT"
echo "$DOCKER_REGISTRY_IP:443/$PATIENT_DOCKER_IMAGE_NAME:v$PATIENT_DOCKER_IMAGE_VERSION is updating..." | tee -a $K8S_LOG_PATH
eval "$PRINT"
ssh -o StrictHostKeyChecking=no $K8S_VM_USERNAME@$K8S_VM_IP kubectl set image $PATIENT_DEPLOYMENT_NAME $PATIENT_CONTAINER_NAME=$DOCKER_REGISTRY_IP:443/$PATIENT_DOCKER_IMAGE_NAME:v$PATIENT_DOCKER_IMAGE_VERSION -n $K8S_NAMESPACE --record=true | tee -a $K8S_LOG_PATH
eval "$PRINT"
#=============password based authentication ; if sshpass utility is available==============#
#read -p "Enter k8s Vm password  to login : " VPASSWORD
#sshpass -p $VPASSWORD ssh $K8S_VM_USERNAME@$K8S_VM_IP kubectl set image $PATIENT_DEPLOYMENT_NAME $PATIENT_CONTAINER_NAME=$DOCKER_REGISTRY_IP:443/$PATIENT_DOCKER_IMAGE_NAME:v$PATIENT_DOCKER_IMAGE_VERSION -n $K8S_NAMESPACE --record=true | tee -a $K8S_LOG_PATH

#CMS_EXTERNAL_DEPLOYMENT
echo "###CMS-EXTERNAL API K8S DEPLOYMENT###" | tee -a $K8S_LOG_PATH
#==============key based authentication=================================#
eval "$PRINT"
echo "$DOCKER_REGISTRY_IP:443/$CMS_EXTERNAL_DOCKER_IMAGE_NAME:v$CMS_EXTERNAL_DOCKER_IMAGE_VERSION is updating..." | tee -a $K8S_LOG_PATH
eval "$PRINT"
ssh -o StrictHostKeyChecking=no $K8S_VM_USERNAME@$K8S_VM_IP kubectl set image $CMS_EXTERNAL_DEPLOYMENT_NAME $CMS_EXTERNAL_CONTAINER_NAME=$DOCKER_REGISTRY_IP:443/$CMS_EXTERNAL_DOCKER_IMAGE_NAME:v$CMS_EXTERNAL_DOCKER_IMAGE_VERSION -n $K8S_NAMESPACE --record=true | tee -a $K8S_LOG_PATH
eval "$PRINT"

#=============password based authentication ; if sshpass utility is available==============#
#read -p "Enter k8s Vm password  to login : " VPASSWORD
#sshpass -p $VPASSWORD ssh $K8S_VM_USERNAME@$K8S_VM_IP kubectl set image $CMS_EXTERNAL_DEPLOYMENT_NAME $CMS_EXTERNAL_CONTAINER_NAME=$DOCKER_REGISTRY_IP:443/$CMS_EXTERNAL_DOCKER_IMAGE_NAME:v$CMS_EXTERNAL_DOCKER_IMAGE_VERSION -n $K8S_NAMESPACE --record=true | tee -a $K8S_LOG_PATH

#CMS_VALIDATION_DEPLOYMENT
echo "###CMS-VALIDATION API K8S DEPLOYMENT###" | tee -a $K8S_LOG_PATH
#==============key based authentication=================================#
eval "$PRINT"
echo "$DOCKER_REGISTRY_IP:443/$CMS_VALIDATION_DOCKER_IMAGE_NAME:v$CMS_VALIDATION_DOCKER_IMAGE_VERSION is updating..." | tee -a $K8S_LOG_PATH
eval "$PRINT"
ssh -o StrictHostKeyChecking=no $K8S_VM_USERNAME@$K8S_VM_IP kubectl set image $CMS_VALIDATION_DEPLOYMENT_NAME $CMS_VALIDATION_CONTAINER_NAME=$DOCKER_REGISTRY_IP:443/$CMS_VALIDATION_DOCKER_IMAGE_NAME:v$CMS_VALIDATION_DOCKER_IMAGE_VERSION -n $K8S_NAMESPACE --record=true
eval "$PRINT"
ssh -o StrictHostKeyChecking=no $K8S_VM_USERNAME@$K8S_VM_IP kubectl get pods -n $K8S_NAMESPACE | tee -a $K8S_LOG_PATH
eval "$PRINT"
echo "AFTER 30 SECONDS RUN BELOW COMMAND TO GET STATUS OF POD " | tee -a $K8S_LOG_PATH
eval "$PRINT"
echo "ssh -o StrictHostKeyChecking=no $K8S_VM_USERNAME@$K8S_VM_IP kubectl get pods -n $K8S_NAMESPACE" | tee -a $K8S_LOG_PATH
eval "$PRINT"

#=============password based authentication ; if sshpass utility is available==============#
#read -p "Enter k8s Vm password  to login : " VPASSWORD
#sshpass -p $VPASSWORD ssh $K8S_VM_USERNAME@$K8S_VM_IP kubectl set image $CMS_VALIDATION_DEPLOYMENT_NAME $CMS_VALIDATION_CONTAINER_NAME=$DOCKER_REGISTRY_IP:443/$CMS_VALIDATION_DOCKER_IMAGE_NAME:v$CMS_VALIDATION_DOCKER_IMAGE_VERSION -n $K8S_NAMESPACE --record=true

