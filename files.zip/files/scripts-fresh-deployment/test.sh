#!/bin/bash

source ./configurations.txt

#deployment
#sed 's/{namespace}/'"$namespace"'/g' $provider_deployment_filepath
	 
#sed 's/{provider_image}/'"$provider_image"'/g' $provider_deployment_filepath
	 
#sed "s/{namespace}/$namespace/g" $provider_deployment_filepath

sed 's/{namespace}/$namespace/g;s/{provider_image}/$provider_image/g' $provider_deployment_filepath

