#!/bin/bash

source ./configurations.txt

#deployment
sed 's/{namespace}/'"$namespace"'/g' $provider_deployment_filepath