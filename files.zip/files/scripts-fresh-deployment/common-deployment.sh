#!/bin/bash

source ./configurations.txt

PRINT="echo ========================================================= | tee -a $k8s_log_path"
echo "logs are saving in $k8s_log_path file"
eval "$PRINT"
date | tee -a $k8s_log_path
eval "$PRINT"

#######################
#NameSpace yaml
#######################
if [ -f $namespace_filepath ]
  then
    echo "sed -i 's/{namespace}/"$namespace"/g' $namespace_filepath"
	echo "applied configuration values to $namespace_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$namespace_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#######################
#docker registry secret
#######################

echo ssh -o StrictHostKeyChecking=no $k8s_vm_username@$k8s_vm_ip "kubectl create secret docker-registry $docker_registry_secretname --docker-server=$docker_registry_ip:443 --docker-username=$docker_registry_username --docker-password=$docker_registry_password -n $namespace" | tee -a $k8s_log_path
eval "$PRINT"

########################
#ingres rules yaml
########################
if [ -f $ingres_rules_filepath ]
  then
    echo sed -i 's/{namespace}/"$namespace"/g' $ingres_rules_filepath
	echo "applied configuration values to $ingres_rules_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$ingres_rules_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#######################
#provider api yaml
#######################
#service

if [ -f $provider_service_filepath ]
  then
    echo sed -i 's/{namespace}/"$namespace"/g' $provider_service_filepath
	echo "applied configuration values to $provider_service_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$provider_service_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#configmap
if [ -f $provider_configmap_filepath ]
  then
    echo sed -i 's/{namespace}/"$namespace"/g' $provider_configmap_filepath
	echo "applied configuration values to $provider_configmap_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$provider_configmap_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#deployment
if [ -f $provider_deployment_filepath ]
  then
    echo sed -i 's/{namespace}/"$namespace"/g;s/{provider_image}/"$provider_image"/g;s/{provider_jarname}/"$provider_jarname"/g;s/{postgres_ency_keyname}/"$postgres_ency_keyname"/g;s/{docker_registry_secretname}/"$docker_registry_secretname"/g' $provider_deployment_filepath
	echo "applied configuration values to $provider_deployment_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$provider_deployment_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#######################
#patient api yaml
#######################
#service

if [ -f $patient_service_filepath ]
  then
    echo sed -i 's/{namespace}/"$namespace"/g' $patient_service_filepath
	echo "applied configuration values to $patient_service_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$patient_service_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#configmap
if [ -f $patient_configmap_filepath ]
  then
    echo sed -i 's/{namespace}/"$namespace"/g' $patient_configmap_filepath
	echo "applied configuration values to $patient_configmap_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$patient_configmap_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#deployment
if [ -f $patient_deployment_filepath ]
  then
    echo sed -i 's/{namespace}/"$namespace"/g;s/{patient_image}/"$provider_image"/g;s/{provider_jarname}/"$patient_jarname"/g;s/{postgres_ency_keyname}/"$postgres_ency_keyname"/g;s/{docker_registry_secretname}/"$docker_registry_secretname"/g' $patient_deployment_filepath
	echo "applied configuration values to $patient_deployment_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$patient_deployment_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#######################
#cms external api yaml
#######################
#service

if [ -f $cms_external_service_filepath ]
  then
    echo sed -i 's/{namespace}/"$namespace"/g' $cms_external_service_filepath
	echo "applied configuration values to $cms_external_service_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$cms_external_service_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#configmap
if [ -f $cms_external_configmap_filepath ]
  then
    echo sed -i 's/{namespace}/"$namespace"/g' $cms_external_configmap_filepath
	echo "applied configuration values to $cms_external_configmap_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$cms_external_configmap_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#deployment
if [ -f $cms_external_deployment_filepath ]
  then
    echo sed -i 's/{namespace}/"$namespace"/g;s/{cms_external_image}/"$cms_external_image"/g;s/{cms_external_jarname}/"$cms_external_jarname"/g;s/{postgres_ency_keyname}/"$postgres_ency_keyname"/g;s/{docker_registry_secretname}/"$docker_registry_secretname"/g' $cms_external_deployment_filepath
	echo "applied configuration values to $cms_external_deployment_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$cms_external_deployment_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#######################
#cms validation api yaml
#######################
#service

if [ -f $cms_validation_service_filepath ]
  then
    echo sed -i 's/{namespace}/"$namespace"/g' $cms_validation_service_filepath
	echo "applied configuration values to $cms_validation_service_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$cms_validation_service_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#configmap
if [ -f $cms_validation_configmap_filepath ]
  then
    echo sed -i 's/{namespace}/"$namespace"/g' $cms_validation_configmap_filepath
	echo "applied configuration values to $cms_validation_configmap_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$cms_validation_configmap_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#deployment
if [ -f $cms_validation_deployment_filepath ]
  then
    echo sed -i 's/{namespace}/"$namespace"/g;s/{cms_external_image}/"$cms_external_image"/g;s/{cms_external_jarname}/"$cms_external_jarname"/g;s/{postgres_ency_keyname}/"$postgres_ency_keyname"/g;s/{docker_registry_secretname}/"$docker_registry_secretname"/g' $cms_validation_deployment_filepath
	echo "applied configuration values to $cms_validation_deployment_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$cms_validation_deployment_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#######################
#redis yaml
#######################
#deployment and service

if [ -f $redis_deployment_filepath ]
  then
    echo sed -i 's/{namespace}/"$namespace"/g;s/{redis_image}/"$redis_image"/g' $redis_deployment_filepath
	echo "applied configuration values to $redis_deployment_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$redis_deployment_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#copying yamls files into k8s master#
echo "######copying all yaml files to $k8s_vm_ip vm######"
eval "$PRINT"
echo scp -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa -r $common_folderpath $provider_folderpath $patient_folderpath $cms_folderpath $redis_folderpath $k8s_vm_username@$k8s_vm_ip:
eval "$PRINT"

#deploy yaml files in k8s master vm
echo "######deploying namespace and ingress controll######"
eval "$PRINT"
echo ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $k8s_vm_username@$k8s_vm_ip "kubectl apply -f $namespace_filepath  --record=true && kubectl apply -f $ingress_controller_filepath --record=true" | tee -a $k8s_log_path
eval "$PRINT"
echo "deploying redis"
eval "$PRINT"
echo ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $k8s_vm_username@$k8s_vm_ip "kubectl apply -f $redis_deployment_filepath --record=true" | tee -a $k8s_log_path
eval "$PRINT"
echo "######deploying provider api######"
eval "$PRINT"
echo ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $k8s_vm_username@$k8s_vm_ip "kubectl apply -f $provider_configmap_filepath --record=true && kubectl apply -f $provider_deployment_filepath --record=true && kubectl apply -f $provider_service_filepath --record=true" | tee -a $k8s_log_path
eval "$PRINT"
echo "######deploying patient api######"
eval "$PRINT"
echo ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $k8s_vm_username@$k8s_vm_ip "kubectl apply -f $patient_configmap_filepath --record=true && kubectl apply -f $patient_deployment_filepath --record=true && kubectl apply -f $patient_service_filepath --record=true" | tee -a $k8s_log_path
eval "$PRINT"
echo "######deploying cms-external api######"
eval "$PRINT"
echo ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $k8s_vm_username@$k8s_vm_ip "kubectl apply -f $cms_external_configmap_filepath --record=true && kubectl apply -f $cms_external_deployment_filepath --record=true && kubectl apply -f $cms_external_service_filepath --record=true" | tee -a $k8s_log_path
eval "$PRINT"
echo "######deploying cms-validation api######"
eval "$PRINT"
echo ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $k8s_vm_username@$k8s_vm_ip "kubectl apply -f $cms_validation_configmap_filepath --record=true && kubectl apply -f $cms_validation_deployment_filepath --record=true && kubectl apply -f $cms_validation_service_filepath --record=true" | tee -a $k8s_log_path
eval "$PRINT"
echo "######deploying ingress-rules######"
eval "$PRINT"
echo ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $k8s_vm_username@$k8s_vm_ip "kubectl apply -f $ingres_rules_filepath --record=true" | tee -a $k8s_log_path
eval "$PRINT"