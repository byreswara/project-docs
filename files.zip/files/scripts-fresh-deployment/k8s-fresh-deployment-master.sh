#!/bin/bash

source ./configurations.txt

PRINT="echo ========================================================= | tee -a $k8s_log_path"
echo "logs are saving in $k8s_log_path file"
eval "$PRINT"
date | tee -a $k8s_log_path
eval "$PRINT"

#######################
#provider api yaml
#######################
#deployment
if [ -f $provider_deployment_filepath ]
  then
    sed -i "s/{docker_registry_ip}/$docker_registry_ip/g" $provider_deployment_filepath
	echo "applied configuration values to $provider_deployment_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$provider_deployment_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#######################
#patient api yaml
#######################
#deployment
if [ -f $patient_deployment_filepath ]
  then
    sed -i "s/{docker_registry_ip}/$docker_registry_ip/g" $patient_deployment_filepath
	echo "applied configuration values to $patient_deployment_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$patient_deployment_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#######################
#cms external api yaml
#######################
#deployment
if [ -f $cms_external_deployment_filepath ]
  then
    sed -i "s/{docker_registry_ip}/$docker_registry_ip/g" $cms_external_deployment_filepath
	echo "applied configuration values to $cms_external_deployment_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$cms_external_deployment_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#######################
#cms validation api yaml
#######################
#deployment
if [ -f $cms_validation_deployment_filepath ]
  then
    sed -i "s/{docker_registry_ip}/$docker_registry_ip/g" $cms_validation_deployment_filepath
	echo "applied configuration values to $cms_validation_deployment_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$cms_validation_deployment_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi

#######################
#copying yamls files into k8s master#
#######################

echo "######copying all yaml files to $k8s_vm_ip vm######"
eval "$PRINT"
scp -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa -r $common_folderpath $provider_folderpath $patient_folderpath $cms_folderpath $redis_folderpath $k8s_vm_username@$k8s_vm_ip:
eval "$PRINT"

#######################
#deploy yaml files in k8s master vm
#######################
echo "######deploying namespace and ingress controll######"
#######################
eval "$PRINT"
ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $k8s_vm_username@$k8s_vm_ip "kubectl apply -f $namespace_filepath  --record=true && kubectl apply -f $ingress_controller_filepath --record=true" | tee -a $k8s_log_path
eval "$PRINT"

#######################
#docker registry secret
#######################
echo "creating docker registry secrect"
#######################
eval "$PRINT"
ssh -o StrictHostKeyChecking=no $k8s_vm_username@$k8s_vm_ip "kubectl create secret docker-registry docker-registry-secret --docker-server=$docker_registry_ip:443 --docker-username=$docker_registry_username --docker-password=$docker_registry_password -n fastplus" | tee -a $k8s_log_path
eval "$PRINT"
echo "deploying redis"
#######################
eval "$PRINT"
ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $k8s_vm_username@$k8s_vm_ip "kubectl apply -f $redis_deployment_filepath --record=true" | tee -a $k8s_log_path
eval "$PRINT"
echo "######deploying provider api######"
#######################
eval "$PRINT"
ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $k8s_vm_username@$k8s_vm_ip "kubectl apply -f $provider_configmap_filepath --record=true && kubectl apply -f $provider_deployment_filepath --record=true && kubectl apply -f $provider_service_filepath --record=true" | tee -a $k8s_log_path
eval "$PRINT"
echo "######deploying patient api######"
#######################
eval "$PRINT"
ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $k8s_vm_username@$k8s_vm_ip "kubectl apply -f $patient_configmap_filepath --record=true && kubectl apply -f $patient_deployment_filepath --record=true && kubectl apply -f $patient_service_filepath --record=true" | tee -a $k8s_log_path
eval "$PRINT"
echo "######deploying cms-external api######"
#######################
eval "$PRINT"
ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $k8s_vm_username@$k8s_vm_ip "kubectl apply -f $cms_external_configmap_filepath --record=true && kubectl apply -f $cms_external_deployment_filepath --record=true && kubectl apply -f $cms_external_service_filepath --record=true" | tee -a $k8s_log_path
eval "$PRINT"
echo "######deploying cms-validation api######"
#######################
eval "$PRINT"
ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $k8s_vm_username@$k8s_vm_ip "kubectl apply -f $cms_validation_configmap_filepath --record=true && kubectl apply -f $cms_validation_deployment_filepath --record=true && kubectl apply -f $cms_validation_service_filepath --record=true" | tee -a $k8s_log_path
eval "$PRINT"
echo "######deploying ingress-rules######"
#######################
eval "$PRINT"
ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $k8s_vm_username@$k8s_vm_ip "kubectl apply -f $ingres_rules_filepath --record=true" | tee -a $k8s_log_path
eval "$PRINT"
#######################
ssh -o StrictHostKeyChecking=no $k8s_vm_username@$k8s_vm_ip "kubectl get all -n fastplus" | tee -a $k8s_log_path
eval "$PRINT"
#######################