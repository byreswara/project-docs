#!/bin/bash

source ./configurations.txt

read -p "Enter tar.gz path including file name ex:/c/users/fastplus-provider-api-20.1.tar.gz : " FILEPATH
read -p "Enter image name ex: fastplus-provider-api or fastplus-patient-api or fastplus-cms-external or fastplus-cms-validation : " DOCKER_IMAGE_NAME
read -p "Enter image version no. ex:20.1 : " VERSION

#==============key based authentication=================================#
scp -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $FILEPATH $DOCKER_VM_USERNAME@$DOCKER_VM_IP:

ssh -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa $DOCKER_VM_USERNAME@$DOCKER_VM_IP "sudo docker load < $FILEPATH && sudo docker tag $DOCKER_IMAGE_NAME:v$VERSION $DOCKER_REGISTRY_IP:443/$DOCKER_IMAGE_NAME:v$VERSION && sudo docker login -u $DOCKER_REGISTRY_USERNAME -p $DOCKER_REGISTRY_PASSWORD $DOCKER_REGISTRY_IP:443 && sudo docker push $DOCKER_REGISTRY_IP:443/$DOCKER_IMAGE_NAME:v$VERSION"

#=============password based authentication ; if sshpass utility is available==============#
#read -p "Enter Docker Vm password  to login : " VPASSWORD
#sshpass -p scp  $VPASSWORD $FILEPATH $DOCKER_VM_USERNAME@$DOCKER_VM_IP:
#sshpass -p ssh  $VPASSWORD $DOCKER_VM_USERNAME@$DOCKER_VM_IP "sudo docker load < $FILEPATH && sudo docker tag $DOCKER_IMAGE_NAME:v$VERSION $DOCKER_REGISTRY_IP:443/$DOCKER_IMAGE_NAME:v$VERSION && sudo docker login -u $DOCKER_REGISTRY_USERNAME -p $DOCKER_REGISTRY_PASSWORD $DOCKER_REGISTRY_IP:443 && sudo docker push $DOCKER_REGISTRY_IP:443/$DOCKER_IMAGE_NAME:v$VERSION"

if [ $? == 0 ]
  then
    echo "### DOCKER_REGISTRY_IP:443/$DOCKER_IMAGE_NAME:v$VERSION pushed sucessfully ###"
  else
    echo " ###docker push failed ### "
fi

#vim /etc/sudoers
#ByreswaraR ALL=(ALL:ALL) NOPASSWD:/usr/bin/docker
#sudo chown root:docker /var/run/docker.sock
#sudo chown -R root:docker /var/run/docker
