#!/bin/bash

source ./configurations.txt

echo "logs are saving in $K8S_LOG_PATH file"
PRINT="echo ========================================================= | tee -a $K8S_LOG_PATH"
echo "###CMS-VALIDATION API K8S DEPLOYMENT###" | tee -a $K8S_LOG_PATH
eval "$PRINT"
date | tee -a $K8S_LOG_PATH
eval "$PRINT"

#==============key based authentication=================================#
echo "$DOCKER_REGISTRY_IP:443/$CMS_VALIDATION_DOCKER_IMAGE_NAME:v$CMS_VALIDATION_DOCKER_IMAGE_VERSION is updating..." | tee -a $K8S_LOG_PATH
eval "$PRINT"
ssh -o StrictHostKeyChecking=no $K8S_VM_USERNAME@$K8S_VM_IP kubectl set image $CMS_VALIDATION_DEPLOYMENT_NAME $CMS_VALIDATION_CONTAINER_NAME=$DOCKER_REGISTRY_IP:443/$CMS_VALIDATION_DOCKER_IMAGE_NAME:$CMS_VALIDATION_DOCKER_IMAGE_VERSION -n $K8S_NAMESPACE --record=true
ssh -o StrictHostKeyChecking=no $K8S_VM_USERNAME@$K8S_VM_IP kubectl get pods -n $K8S_NAMESPACE | tee -a $K8S_LOG_PATH
eval "$PRINT"
echo "AFTER 30 SECONDS RUN BELOW COMMAND TO GET STATUS OF POD " | tee -a $K8S_LOG_PATH
eval "$PRINT"
echo "ssh -o StrictHostKeyChecking=no $K8S_VM_USERNAME@$K8S_VM_IP kubectl get pods -n $K8S_NAMESPACE" | tee -a $K8S_LOG_PATH
eval "$PRINT"

#=============password based authentication ; if sshpass utility is available==============#
#read -p "Enter k8s Vm password  to login : " VPASSWORD
#sshpass -p $VPASSWORD ssh $K8S_VM_USERNAME@$K8S_VM_IP kubectl set image $CMS_VALIDATION_DEPLOYMENT_NAME $CMS_VALIDATION_CONTAINER_NAME=$DOCKER_REGISTRY_IP:443/$CMS_VALIDATION_DOCKER_IMAGE_NAME:$CMS_VALIDATION_DOCKER_IMAGE_VERSION -n $K8S_NAMESPACE --record=true

if [ $? == 0 ]
  then
    echo "$CMS_VALIDATION_DEPLOYMENT_NAME is sucessfully updated with $DOCKER_REGISTRY_IP:443/$CMS_VALIDATION_DOCKER_IMAGE_NAME:v$CMS_VALIDATION_DOCKER_IMAGE_VERSION" | tee -a $K8S_LOG_PATH
	eval "$PRINT"
  else
    echo "FAILED to update the $DOCKER_REGISTRY_IP:443/$CMS_VALIDATION_DOCKER_IMAGE_NAME:v$CMS_VALIDATION_DOCKER_IMAGE_VERSION image" | tee -a $K8S_LOG_PATH
	eval "$PRINT"
fi