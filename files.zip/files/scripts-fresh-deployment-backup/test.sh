#!/bin/bash

source ./configurations.txt
#deployment
if [ -f $namespace_filepath ]
  then
    sed -i 's/{namespace}/"$namespace"/g' $namespace_filepath
	echo "applied configuration values to $namespace_filepath" | tee -a $k8s_log_path
	eval "$PRINT"
  else
    echo "$namespace_filepath does not exist" | tee -a $k8s_log_path
	exit 1
fi
fi